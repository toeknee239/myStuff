﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HangMan
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] words = { "red", "green", "yellow", "blue", "orange" };
            char[] alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
            string str = new string(alpha);


            Random random = new Random();
            int randomIndex = random.Next(0, words.Length);
            string randomWord = words[randomIndex];
            string hiddenWord = "";
            randomWord = randomWord.ToUpper();

            int lives = 5;


            for (int i = 0; i < randomWord.Length; i++)
            {
                hiddenWord += "*";
            }

            while (hiddenWord.Contains("*") && lives > 0)
            {
                for (int i = 0; i < alpha.Length; i++)
                {
                    Console.Write(str[i] + " ");
                }

                Console.WriteLine();
                Console.WriteLine($"lives: {lives}");
                Console.WriteLine($"Your word has {randomWord.Length} letters");
                Console.WriteLine($"Mystery Word: {hiddenWord.ToUpper()}");
                Console.Write("Guess a letter: ");
                char letter = char.Parse(Console.ReadLine());
                letter = Char.ToUpper(letter);

                bool containsLetter = false;

                for (int i = 0; i < randomWord.Length; i++)
                {
                    if (randomWord[i] == letter)
                    {
                        containsLetter = true;
                        Console.WriteLine(letter.ToString());
                        hiddenWord = hiddenWord.Remove(i, 1);
                        hiddenWord = hiddenWord.Insert(i, letter.ToString());
                        hiddenWord = hiddenWord.ToUpper();


                        Console.WriteLine($"{letter} is contained in the mystery word");

                        Console.Clear();
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Clear();
                    }
                }

                if (containsLetter == true)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"{letter} is contained in the mystery word");

                }
                else
                {
                    Console.WriteLine("Try again...");
                    lives--;
                }


                if (lives == 0)
                {
                    Console.Clear();
                    Console.WriteLine($"GAME OVER!, The mystry word was, {randomWord}");
                }
                else if (lives > 0 && hiddenWord.Contains(randomWord))
                {
                    Console.WriteLine($"YOU WIN, the mystrey word was, {randomWord}!!");

                }

            }

            Console.ReadLine();
        }
    }
}
