﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] myWord = "HELLO WORLD".ToCharArray();
            char[] alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();

            List<char> rightGuesses = new List<char>();
            List<char> wrongGuesses = new List<char>();
            List<char> allLetters = new List<char>(alpha);
            List<char> allGuesses = new List<char>();



            bool gameLoop = true;

            while (gameLoop)
            {       
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Remaining letters: ");

                foreach (char item in alpha)
                {
                    if (allLetters.Contains(item))
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write(item);
                    }
                    else if (rightGuesses.Contains(item))
                    {      
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.Write(item);
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write(item);
                    }
                }
                Console.WriteLine();


                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Right guesses: ");

                foreach (char item in myWord)
                {
                    if (rightGuesses.Contains(item))
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.Write(item);
                        char correctItem = item;
                        
                    }
                    else
                    {
                        Console.Write(" ");
                    }
                }


                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine();
                Console.Write("Wrong guesses: ");
                Console.ForegroundColor = ConsoleColor.Red;


                // Dont under stand this line, but it works...
                wrongGuesses.ForEach(x => Console.Write(x));
                

                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.White;


                Console.WriteLine("Enter letter to change color: ");
                char letter = char.Parse(Console.ReadLine());
                letter = char.ToUpper(letter);                

                if (myWord.Contains(letter))
                {
                    allLetters.Remove(letter);                    

                    rightGuesses.Add(letter);
                    allGuesses.Add(letter);
                    Console.ForegroundColor = ConsoleColor.Green;
                    
                    Console.Write(letter);
                }
                else
                {
                    wrongGuesses.Add(letter);

                    allLetters.Remove(letter);                                                          
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write(letter);
                }
                Console.Clear();               

            }
            Console.ReadLine();
        }
    }
}
