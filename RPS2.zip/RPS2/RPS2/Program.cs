﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RockPaperScissors
{
    class Program
    {
        static void Main(string[] args)
        {
            string result, Computer; 


            int playerScore = 0;
            int computerScore = 0;

            int RPS;

            bool playAgain = true;
            while (playAgain)
            {

                {
                    Console.BackgroundColor = ConsoleColor.Blue;
                    Console.WriteLine("SCORE: PLAYER: {0}      COMPUTER: {1} ", playerScore, computerScore);
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.WriteLine("Let's play, ROCK-PAPER-SCISSORS...");
                    Console.WriteLine("ROCK - 1");
                    Console.WriteLine("PAPER - 2");
                    Console.WriteLine("SCISSORS - 3");

                    result = Console.ReadLine();
                    


                    Console.WriteLine("You Chose: " + playerChoice);


                    Random random = new Random();                  

                    RPS = random.Next(0, 2);

                    switch (RPS)
                    {
                        case 0:
                            Computer = "ROCK";
                            Console.WriteLine("Computer chose: ROCK");
                            if (result == "1")
                            {
                                Console.WriteLine("DRAW... TRY AGAIN!");
                            }
                            else if (result == "2")
                            {
                                Console.WriteLine("PLAYER WINS!");
                                playerScore++;

                            }
                            else if (result == "3")
                            {
                                Console.WriteLine("COMPUTER WINS!");
                                computerScore++;
                            }
                            break;

                        case 1:
                            Computer = "PAPER";
                            Console.WriteLine("Computer chose: PAPER");
                            if (result == "2")
                            {
                                Console.WriteLine("DRAW... TRY AGAIN!");
                            }
                            else if (result == "3")
                            {
                                Console.WriteLine("PLAYER WINS!");
                                playerScore++;
                            }
                            else if (result == "1")
                            {
                                Console.WriteLine("COMPUTER WINS!");
                                computerScore++;
                            }
                            break;
                        case 2:
                            Computer = "PAPER";
                            Console.WriteLine("Computer chose: PAPER");
                            if (result == "3")
                            {
                                Console.WriteLine("DRAW... TRY AGAIN!");
                            }
                            else if (result == "1")
                            {
                                Console.WriteLine("PLAYER WINS!");
                                playerScore++;
                            }
                            else if (result == "2")
                            {
                                Console.WriteLine("COMPUTER WINS!");
                                computerScore++;

                            }
                            break;
                            
                      
                    }
                    Console.WriteLine();
                
                    Console.WriteLine("DO YOU WANT TO PLAY AGAIN? Y/N");
                    string loop = Console.ReadLine();
                    if (loop == "y")
                    {
                        playAgain = true;
                        Console.Clear();

                    }
                    else if (loop == "n")
                    {
                        playAgain = false;

                    }


                }



            }
            

        }

       
    }
}
